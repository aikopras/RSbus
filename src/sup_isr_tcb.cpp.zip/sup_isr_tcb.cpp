//******************************************************************************************************
//
// file:      sup_isr_tcb.cpp
// purpose:   Support file for the RS-bus library. 
//            Defines the Interrupt Service routine (ISR) that counts the polling pulses transmitted by
//            the master. Once this decoder is polled, the ISR can send data back via its USART.
//            Uses a TCB as event counter. The option of using TCB as event counter only exists on
//            DxCore processors, but not on MegaCoreX (such as the Nano Every) or traditional ATmega
//            processors (such as the UNO.
// history:   2021-10-16 ap V1.0 initial version
//
// This source file is subject of the GNU general public license 2,
// that is available at the world-wide-web at http://www.gnu.org/licenses/gpl.txt
//
// If data is available for sending, the data should be entered  into the "data2send" variable and
// the "data2sendFlag" should be set.
// TCB1 counts the number of RS-bus pulses and triggers an interrupt once the counter "matches"
// the RS-bus address. .
//
// TCB as Event User - Introduction
// ================================
// TCB can be configured as event user. Two types of event usage can be configured:
// 1) CAPT: in this mode the normal clock is used, and captured in case of an event
// 2) COUNT: Events are used as clock source, and counted according to the selected mode
// => We need to configure as COUNT 
//
// TCB as Event User - COUNT
// -------------------------
// Copied from the AVR128DA datasheet:
// The COUNT event user is enabled on the peripheral by modifying the Clock Select
// (CLKSEL) bit field in the Control A (TCBn.CTRLA) register to EVENT and setting up
// the Event System accordingly. If the Capture Event Input Enable (CAPTEI) bit in the 
// Event Control (TCBn.EVCTRL) register is written to ‘1’, incoming events will result
// in an event action as defined by the Event Edge (EDGE) bit in Event Control (TCBn.EVCTRL)
// register and the Timer Mode (CNTMODE) bit field in Control B (TCBn.CTRLB) register.
// The event needs to last for at least one CLK_PER cycle to be recognized.
//  
// The Timer Mode (CNTMODE) bit field in Control B (TCBn.CTRLB) register must be set to
// Periodic Interrupt Mode.
// 
// TCB - Periodic Interrupt Mode
// -----------------------------
// In Periodic Interrupt mode, the counter (TCBx.CNT) counts to the value stored in TCBx.CCMP.
// If the value is matched, a CAPT interrupt is generated. In the CAPT ISR the interrup flag
// must be cleared, and data (if available) may be transmitted using the USART.
//
// According to the datasheet, a CAPT interrupt automatically resets / clears the counter 
// (TCBx.CNT) to bottom (0). To ensure that after a complete pulse train (thus at the start
// of the silence period) the counter value is 130, the ISR will "reload" the counter with
// the previous CCMP value + 1.  
//
// TCB initialisation
// ------------------
// The counter will be reinitialised / reset by CheckPolling() during the silence period.
// This ensures that the counter value is zero when the next pulse train starts.
// Initialisation is also needed after start-up or after the RS-bus signal was lost and reappears.
// To determine if initialisation is needed, checks are performed during the silence period
// if the counter value matches 130. If this is not the case, a new initialisation takes place.
// If the RS-bus address has changed, CheckPolling() will load the Compare register (TCBx.CCMP)
// to refelct the new RS-bus address
// 
// RS-Bus input pin
// ================
// The RS-Bus can be connected to any input pin that is available to the Event system.
// The Event system triggers on positive edges, although the edge can still be inverted via
// the port pin control register.
//
// Parity errors
// =============
// If the master station detects a parity error, it will enlarge the silence period 
//
// Pins:
// =====
// - a RS-Bus input pin
// - a transmit pin for the UART
// 
// Temporary, for testing:
// PF4: RS-Bus transmit (USART 2, alt port)
// PA2: Event system
// PA3: Compare-Match Interrupt
// PB3: CheckPolling: Two millisecond timer & Overflow detected
// PC4: CheckPolling: Silence is detected (RTC.CNT == 0)
// PC7: Main loop, to check CPU usage
// 
//************************************************************************************************
#include <Arduino.h>
#include <Event.h>
#include "RSbus.h"
#include "sup_isr.h"
#include "sup_usart.h"


// This code will only be used if we define in RSbusVariants.h the "RSBUS_USES_TCB" directive
#if defined(RSBUS_USES_TCB0) || defined(RSBUS_USES_TCB1) || defined(RSBUS_USES_TCB2) || \
    defined(RSBUS_USES_TCB3) || defined(RSBUS_USES_TCB4)

//************************************************************************************************
// The following objects are instantiated elsewhere, but are used here
extern RSbusHardware rsbusHardware;  // instantiated in "RS-bus.cpp"
extern volatile RSbusIsr rsISR;      // instantiated in "RS-bus.cpp"
extern USART rsUSART;                // instantiated in "sup_usart.cpp" We only use init()


//**********************************************************************************************
// RSbusIsr: constructor
//**********************************************************************************************
RSbusIsr::RSbusIsr(void) {           // Define the constructor
  data2send = 0;                     // Empty our send data byte
  address2use = 0;
  data2sendFlag = false;             // No, we don't have anything to send yet
  data4usartFlag = false;
  tLastCheck = millis();             // Current time
}

   
//******************************************************************************************************
//******************************************************************************************************
// The RSbusHardware class is responsible for controlling the RS-bus hardware, thus the TCB that counts
// the polling pulses send by the master, and the USART connected to an output pin to send messages
// to the master.
// Messages are: 8 bit, no parity, 1 stop bit, asynchronous mode, 4800 baud.
// The "attach" method initialises the TCB and USART.
// A detach method is available to disable the TCB, which is needed before a decoder gets restarted.
// Note regarding the code: instead of the "RSbusHardware::attach" method we could have directly used
// the RSbusIsr and USART class constructors. However, since we also need a "RSbusHardware::detach" method
// to stop the rs_interrupt service routine, for symmetry reasons we have decided for an "attach"
// and "detach".

void init_tcb(void) {
  // Initialise the TCB in Periodic Interrupt Mode
  // Reset the main timer control registers, needed since the Arduino core creates presets
  TCB1.CTRLA = 0;
  TCB1.CTRLB = 0;
  TCB1.EVCTRL = 0;
  TCB1.INTCTRL = 0;
  // Initialise the control registers 
  TCB1.CTRLA = TCB_ENABLE_bm | TCB_CLKSEL_EVENT_gc; // Enable TCB and count Events
  TCB1.CTRLB = TCB_CNTMODE_INT_gc;                  // Periodic Interrupt Mode
  TCB1.EVCTRL = TCB_CAPTEI_bm;                      // Enable input capture events
  TCB1.INTCTRL |= TCB_CAPT_bm;                      // Enable CAPT interrupts
  TCB1.CCMP = rsISR.address2use;                    // Initial RS-Bus address
}


// TODO: Updaten naar nieuwe Event library
void init_events(void) {
  // Set Event generator: DCC input starts timer
  Event0.set_generator(gen0::pin_pa0);      // Set PA0 as event generator = RSBus RX
  // Set Event Users
  Event0.set_user(user::evouta_pin_pa2);    // Set PA2 as event user = Debug
  Event0.set_user(user::tcb1_cnt);          // Set TCB1 as event user
  // Start the event channel
  Event0.start();
}


RSbusHardware::RSbusHardware() {                     // Constructor
  masterIsSynchronised = 0;                          // Is RTC.CNT zero in the silence period
  parityErrors = 0;                                  // Counter for the number of 10,7ms gaps
  parityErrorFlag = false;                           // Flag for the previous cycle
 
}


//void RSbusHardware::attach(uint8_t usartNumber) {
void RSbusHardware::attach(uint8_t usartNumber, uint8_t rx_pin) {
  // In principle we could have implemented the 'interruptModeRising' parameter if we include
  // something like PORT*.PIN*CTRL |= PORT_INVEN_bm  
  rx_pin_used = rx_pin;                              // Store, to allow a detach later
  rx_pin_used = PIN_PA0;                             // TODO: weg als event lib af is 
  rsUSART.init(usartNumber, !swapUsartPin);          // RS-bus transmission hardware (USART)
  init_tcb();
  init_events();
}


void RSbusHardware::detach(void) {
  TCB1.EVCTRL  &= ~TCB_CAPTEI_bm;                    // Disable input capture events
  TCB1.INTCTRL &= ~TCB_CAPT_bm;                      // Disable CAPT interrupts
}

volatile bool gezonden = false;
//************************************************************************************************
// checkPolling(): Called from main as frequent as possible
//************************************************************************************************
// See sup_isr_rtc.cpp for timing and explanation regarding operation of checkPolling().  
// CheckPolling() ignores all checks, except check 3 and check 5
// - check 1: ignore
// - check 2: ignore 
// - check 3: TCBx.CCMP should be 130 => reinitialise values, including RS-bus address and flags
// - check 4: ignore 
// - check 5: only happens after more than 8ms of silence: parity error (or signal loss) 
// - check 6: ignore 
// - check 7: 12ms of silence: seems we lost the RS-signal
void RSbusHardware::checkPolling(void) {
  unsigned long currentTime = millis();                // will not chance during sub routine
  if ((currentTime - rsISR.tLastCheck) >= 2) {         // Check once every 2 ms
    rsISR.tLastCheck = currentTime;   
    digitalWriteFast(PIN_PB3, HIGH);
    digitalWriteFast(PIN_PB3, LOW);
    uint16_t currentCnt = TCB1.CNT;                    // will not chance during sub routine
    if (currentCnt == rsISR.lastPulseCnt) {            // This is a silence period
      rsISR.timeIdle++;                                // Counts which 2ms check we are in
      digitalWriteFast(PIN_PC4, HIGH);
      digitalWriteFast(PIN_PC4, LOW);
      switch (rsISR.timeIdle) {                        // See figures above
      case 1:                                          // RTC.CNT differs from previous count
      case 2:                                          // May also occur if UART send byte 
      case 4:                                          // Same as case 3, nothing new
      case 6:                                          // Same as case 5, nothing new
      break;
      case 3:                                          // Third check 
        if (TCB1.CNT == 130) {
          masterIsSynchronised = true; 
          TCB1.CNT = 0;                                // Start a new polling cycle
          rsISR.lastPulseCnt = 0;                      // Update as well, since we still have silence
          if (rsISR.data2sendFlag) {
            TCB1.CCMP = rsISR.address2use;             // The RS-bus address may be changed
            rsISR.ccmpValue = rsISR.address2use;       // For the ISR to reinitialise TCBx.CNT
            rsISR.data4usartFlag = true;               // Tell the ISR that data may be send
          }
        }
        else {
          TCB1.CNT = 0;                                // Start a new polling cycle
          rsISR.lastPulseCnt = 0;                      // Update as well, since we still have silence
          masterIsSynchronised = 0;
          Serial1.println("No Sync");
        }
        parityErrorFlag = false;                       // Cycle is over. Clear flag
      break;
      case 5:                                          // 8ms of silence
        parityErrorFlag = true;                        // Retransmission may be attempted in next cycle
        parityErrors++;                                // Keep track of number of parity errors
        digitalWriteFast(PIN_PB3, HIGH);
        digitalWriteFast(PIN_PB3, LOW);
      break;
      case 7:                                          // 12ms of silence
        parityErrorFlag = false;                       // Wasn't a parity error
        parityErrors--;                                // Wasn't a parity error
        masterIsSynchronised = false;                  // But worse: a RS-bus signal loss
        rsISR.data2sendFlag = false;                   // Cancel possible data waiting for ISR
        rsISR.data4usartFlag = false;                  // Cancel possible data waiting for ISR
      break;
      default:                                         // Silence >= 14ms
      break;
      };
    }
    else {                                              // Not a silence period
      rsISR.lastPulseCnt = currentCnt;                  // CNT can have any value <= 129
      rsISR.timeIdle = 1;                               // Reset silence (idle) period counter
    }
  }
}


//************************************************************************************************
// Define the TCB-based Interrupt Service routine (ISR) for the RS-bus
//************************************************************************************************
// TODO: Nu alleen nog maar voor TCB1
ISR(TCB1_INT_vect) {
  // Note: the ISR automatically clears the pulse counter TCBx.CNT
  TCB1.INTFLAGS |= TCB_CAPT_bm;             // We had an interrupt. Clear!
  TCB1.CNT = rsISR.ccmpValue + 1;           // Revert clearing the pulse counter
  digitalWriteFast(PIN_PA3, HIGH);
  digitalWriteFast(PIN_PA3, LOW);
  if (rsISR.data4usartFlag) {
    (*rsUSART.dataRegister) = rsISR.data2send;
      rsISR.data2sendFlag = false;          // RSbusConnection::sendNibble may now prepare new data
      rsISR.data4usartFlag = false;         // CheckPolling may now select a new RS-bus address
  } 
}


#endif // #if defined(RSBUS_USES_TCB....)
